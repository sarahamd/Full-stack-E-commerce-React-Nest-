export class CreateCheckOutDto {}
