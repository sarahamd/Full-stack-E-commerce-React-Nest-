export enum Role {
  User = 'user',
  Admin = 'admin',
  Seller = 'seller',
}
